#pragma once
#include <string>
using namespace std;
 enum TypeOfIngredient{
        None,
        Flour,
        Egg,
        Salt,
        BakingPowder,
        Milk
    };

class ingredient
{
private:
    int ingredientAmount;
    string TypeOfIngredient;
public:
    int GetIngredientAmount();
    bool operator==(const ingredient& otheingredient);

    ingredient();
    ingredient(int newIncredientAmount, TypeOfIngredient tp ) const{
        return TypeOfIngredient.tp;
    };
    ~ingredient();
    void ingredientName()
};
string ingredientName() const{


}

