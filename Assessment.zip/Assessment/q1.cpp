#include <iostream>
#include <fstream>
#include <string>


enum TypeOfIngredient {
    None,
    Flour,
    Egg,
    Sugar,
    Salt,
    BakingPowder,
    Milk
}
class Ingredient {
private:
    int amount;
    TypeOfIngredient type;
public:
Ingredient(); 
Ingredient(int newAmount, TypeOfIngredient newtype); 
    int GetAmount(); 
    TypeOfIngredient GetType();
     ~Ingredient();
    
    bool operator==(const Ingredient& other); 
    string IngredientName(); 
    
};
Ingredient::Ingredient(){
    amount = 0;
    TypeOfIngredient = 'none';
}
Ingredient::Ingredient(int m, TypeOfIngredient t){
    amount = n;
    TypeOfIngredient = t;
}
Ingredient::GetAmount(){
    return amount;
}
Ingredient::~Ingredient(){

}
Ingredient::GetType(){
    return type;
}
Ingredient::operator==(const Ingredient& otherType){
    return type == otherType.type;
}
Ingredient::IngredientName(){
    switch (type)
    {
    case Flour: return "Flour";
        break;
    case Egg: return "Egg";
        break;
    case Salt: return "salt";
        break;
   case Sugar: return "suger";
        break;
    case BakingPowder: return "Bankingpowder";
        break;
    default: return "Milk";
        break;
    }
}
int main(){
    Cake cakeObject = Cake();
    cakeObject.Bake();
    return ;
}