#include "Triangle.h"
int Triangle::Area(){
    return mWidth * mHeigth / 2;
}