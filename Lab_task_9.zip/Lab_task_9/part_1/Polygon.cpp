#pragma once
#include "Polygon.h"
void Polygon::SetValue(int width, int height){
    mWidth = width;
    mHeigth = height;
}
int Polygon::Area(){
    return 0;
}