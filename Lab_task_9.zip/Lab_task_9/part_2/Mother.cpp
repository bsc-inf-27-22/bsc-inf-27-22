#include "Mother.h"
#include <iostream>
using namespace std;

Mother::Mother(){
    cout << "Mother: no parameters \n";
    
    };
    Mother::Mother(int a){
        cout <<"Mother : int parameter\n";
    }