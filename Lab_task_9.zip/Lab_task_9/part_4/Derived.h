#pragma once

#include "Base.h"
class Derived : public Base
{
private:
    int a;
public:
    Derived();
   
};

