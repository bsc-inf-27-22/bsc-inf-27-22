#include "Base.h"

void Base::DummyFunction(){

}