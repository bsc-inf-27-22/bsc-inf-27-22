#include <iostream>
#include <fstream>
using namespace std;

class Cake {
private:
    Ingredient* ingredient[5];
    int validIngredient;

    void AddIngredient();
    void SaveToFile();
    void ShowIngredient();
    TypeOfIngredient SelectIngredientType();

public:
    Cake();
    void Bake();
};

Cake::Cake() {
    for (int i = 0; i < 5; ++i) {
        ingredient[i] = nullptr;
    }
    validIngredient = 0;
}

void Cake::AddIngredient() {
    if (validIngredient == 5) {
        cout << "The array is full." << std::endl;
        return 0;
    }

    Ingredient* newIngredient = new Ingredient;
    newIngredient->type = SelectIngredientType();
    cout << "Enter the amount of the ingredient: ";
    cin >> newIngredient->amount;

    bool alreadyExists = false;
    for (int i = 0; i < 5; ++i) {
        if (ingredients[i] != nullptr && ingredients[i]->type == newIngredient->type) {
            alreadyExists = true;
            break;
        }
    }

    if (alreadyExists) {
        std::cout << "Ingredient already exists. Not added." << endl;
        delete newIngredient;
        return;
    }

    for (int i = 0; i < 5; ++i) {
        if (ingredients[i] == nullptr) {
            ingredients[i] = newIngredient;
            ++validIngredientCount;
            cout << "Ingredient added successfully." << endl;
            return;
        }
    }
}

void Cake::SaveToFile() {
    ofstream file("cake.txt");
    if (!file.is_open()) {
        cout << "Failed to open." << endl;
        return ;
    }

    for (int i = 0; i < 5; ++i) {
        if (ingredients[i] != nullptr) {
            file << "Ingredient: " << ingredients[i]->type << ", Amount: " << ingredients[i]->amount << endl;
        }
    }

    file.close();
    cout << "Ingredients saved to file." << endl;
}

void Cake::ShowIngredient() {
    bool hasValidIngredients = false;
    for (int i = 0; i < 5; ++i) {
        if (ingredients[i] != nullptr) {
            cout << "Ingredient: " << ingredients[i]->type << ", Amount: " << ingredients[i]->amount << endl;
            hasValidIngredients = true;
        }
    }

    if (!hasValidIngredients) {
        cout << "No valid ingredients to show." << endl;
    }
}

TypeOfIngredient Cake::SelectIngredientType() {
    int choice;
    cout << "Type of ingredient options:" << endl;
    cout << "1- Flour '\n ' 2- Egg '\n' 3- Sugar '\n' 4- Salt '\n' 5- Baking Powder '\n' 6- Milk" <<endl;
    cout << "Please select an ingredient: ";
    cin >> choice;
    return static_cast<TypeOfIngredient>(choice - 1);
}

void Cake::Bake() {
    int option;
    do {
        cout << "Options\n1- Add an ingredient.\n2- Show all added ingredients.\n3- Save ingredients to file.\n4- Quit.\nWhat would you like to do? ";
        cin >> option;

        switch (option) {
            case 1:
                AddIngredient();
                break;
            case 2:
                ShowAllIngredients();
                break;
            case 3:
                SaveIngredientsToFile();
                break;
            case 4:
                cout << "Quitting..." << std::endl;
                break;
            default:
                cout << "Invalid option. Please try again." << std::endl;
        }
    } while (option != 4);
}